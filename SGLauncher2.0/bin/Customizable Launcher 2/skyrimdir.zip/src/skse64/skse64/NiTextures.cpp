#include "skse64/NiTextures.h"

RelocAddr<_CreateSourceTexture> CreateSourceTexture(0x00C68D20);
RelocAddr<_LoadTexture> LoadTexture(0x01295C30);