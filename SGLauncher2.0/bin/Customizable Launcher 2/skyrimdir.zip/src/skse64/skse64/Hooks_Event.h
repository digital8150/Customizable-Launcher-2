#pragma once

void Hooks_Event_Commit(void);
