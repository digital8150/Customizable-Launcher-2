#pragma once

#include "skse64/ScaleformTypes.h"
